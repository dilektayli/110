import 'package:beetourist_app/login_page.dart';
import 'package:beetourist_app/signup_page.dart';
import 'package:beetourist_app/welcome_page.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';