package com.beetourist.app.v2.beetourist_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
